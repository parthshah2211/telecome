var Sequelize = require('sequelize');
var Op = Sequelize.Op;
const { globalMessages } = require("../global/globalMessage");
const Plan = require('../models/plans');
const Provider = require("../models/provider")
const ServiceHasProvider = require("../models/servicehasprovider")
const zipCode1 = require("../models/zipcode")

exports.provider =(req,res,next)=>{
const name=req.body.name
const logo=req.body.logo
const des=req.body.des
const contact=req.body.contact
const website=req.body.website
const serviceId=req.body.serviceId
const zipCode=req.body.zipCode
    Provider.create({
        name:name,
        logo:logo,
        des:des,
        contact:contact,
        website:website,
        zip_code:zipCode,  
    })
.then(response => {
    // console.log(response.id,"hello world")
    const providerId=response.id
    console.log(providerId)
   for(let i=0; i<serviceId.length; i+=2){
    let service=serviceId[i]
    console.log(service,"helllo")
    ServiceHasProvider.create({
        ServiceId:service,
        ProviderId:providerId,
    }).then((response) => {
        console.log(response)
    })
   }
}).then(response=>{
    res.status(201).send(globalMessages.PROVIDERADDEDSUCCESSFULLY)
})
.catch((err)=>{
    console.log(err)
    res.send(globalMessages.PROVIDERADDEDFAIL)

})
}
exports.providerDisplay=(req,res,next)=>{
    Provider.findAll(  
        // attributes["id","name","des","contact","website",""],
    )
    .then((response)=>{
       console.log(response)
       res.status(200).send(response)
    }).catch((err)=>{
    })
}
exports.providerPlanDisplay = (req, res, next) => {
    console.log("parth")
    Provider.findAll(
        {
            include:
                [
                    {
                        model:Plan,
                        attributes: ["plan"],
                        through: {
                            attributes: []
                          }
                    },
            ]
        }  
        // attributes["id","name","des","contact","website",""],
    )
    .then((response)=>{
       console.log(response)
       res.status(200).send(response)
    }).catch((err)=>{

    })
}