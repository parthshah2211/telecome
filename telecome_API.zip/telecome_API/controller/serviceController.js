
const Service= require("../models/service")

exports.service =(req,res,next)=>{

const service=req.body.service
console.log(service)
Service.create({
    service:service,
}).then(response => {
res.send(response)
}).catch((err)=>{
    console.log(err)
    res.status(500).send("Server Error");
})

}