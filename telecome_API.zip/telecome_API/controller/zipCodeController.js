const { response } = require('express')
const zipCodeModel=require('../models/zipcode')

exports.zipCodeCreateController=(req,res,next) => {
    const zipCode=req.body.zipCode
    zipCodeModel.create({
        zip_code:zipCode
    }).then((response)=>{
        res.status(201).send(response)
        console.log(response)
    }).catch((err) => {
        res.status(422).send(err)
        console.log(err)
    })
}

// showZipCode
exports.showZipCodeController = (req,res,next)=>{
    zipCodeModel.findAll().then(response => {
        console.log(response+"response")
        res.status(200).send(response)}).catch((err)=>{
            response.status(404).send(err)
        })    
}