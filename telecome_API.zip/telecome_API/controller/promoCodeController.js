
const promoCode= require("../models/promocode")

exports.promoCode =(req,res,next)=>{

    const promo_code = req.body.promo_code
    const promo_code_detail = req.body.promo_code_detail
    console.log(promo_code,promo_code_detail)
promoCode.create({
    promo_code: promo_code,   
    promo_code_detail:promo_code_detail
}).then(response => {
res.send(response)
}).catch((err)=>{
    console.log(err)
    res.status(500).send("Server Error");
})
}