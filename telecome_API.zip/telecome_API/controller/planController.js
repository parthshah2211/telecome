var Sequelize = require("sequelize");
var Op = Sequelize.Op;
const Publishable_Key = 'pk_test_51LUsbOSFn9zBQXriWHmsgtatq0cnYfY1XMvLoA7APoTDwsXEmFkvHTv7jGu9T9N6XAQSk8OhB4MakAAShkY6qtDf00HdQYQunr'
const { response } = require("express");
const { globalMessages } = require("../global/globalMessage");
const Plan = require("../models/plans");
const PromoCode = require("../models/promocode");
const Provider = require("../models/provider");
const Service = require("../models/service");
const PlanHasService = require("../models/planHasService");

const { where } = require("sequelize");
// create plan controllers
exports.createPlan = (req, res, next) => {
  const name = req.body.name;
  const price = req.body.price;
  const des = req.body.des;
  const TalkTime = req.body.TalkTime;
  const data = req.body.data;
  const validity = req.body.validity;
  const type = req.body.type;
  const dataSpeed = req.body.dataSpeed;
  const sms = req.body.sms;
  const providerId = req.body.providerId;
  const serviceId = req.body.serviceId;
  Plan.create({
    name: name,
    price: price,
    des: des,
    talk_time: TalkTime,
    data: data,
    type: type,
    validity: validity,
    data_speed: dataSpeed,
    sms: sms,
    PromoCodeId: req.body.promoCodeId,
    // ServiceId:req.body.serviceId,
    ProviderId: providerId,
  })
    .then((response) => {
      let id = response.id;
      for (let i = 0; i < serviceId.length; i += 2) {
        let service = serviceId[i];
        PlanHasService.create({
          PlanId: id,
          ServiceId: service,
        });
      }
      return res.status(201).send(globalMessages.PLANCREATEDSUCCSSFULL);
    })
    .catch((err) => {
      console.log(err + "error");
      res.status(422).send(globalMessages.PLANCREATEDFAIL);
    });
};

// show plan controller

exports.showPlanController = (req, res, next) => {
  const operatorsAliases = {
    $like: Op.like,
  };
  const where = {
  };
  const { validity, data_speed, data, promo_code, ProviderId } = req.query;
  // console.log(data_speed.length)
    if (validity)
    {
      where.validity = String(validity).split(",").length == 1 ? {  [Op.like]: `%${validity}%` } : { [Op.in]: data };
    }
  if (data_speed) {
      if (String(data_speed).split(',').length == 1) {
        where.data_speed = { [Op.like]: `%${data_speed}%` };
    }
      else {
      where.data_speed = { [Op.in]: data_speed };
    }
  }
  if (data) {
      if (String(data).split(',').length == 1)
      {
      where.data = { [Op.like]: `%${data}%` };
    }
    else {
      where.data = { [Op.in]: data };
    }
  }
  if (ProviderId) {
      if (String(ProviderId).split(',').length == 1)
      {
      where.ProviderId = { [Op.like]: `%${ProviderId}%` };
      }
      else {
      where.ProviderId = { [Op.in]: ProviderId };
    }
  }
  // if (ProviderId) where.ProviderId = { [Op.in]: ProviderId }
  // if (ProviderId) where.ProviderId = {  [Op.or]: { [Op.in]: ProviderId,[Op.like]: `%${ProviderId}` }     }
  console.log(where);
  console.log(ProviderId);
  Plan.findAll({
    attributes: [
      "name",
      "price",
      "des",
      "talk_time",
      "data",
      "validity",
      "type",
      "data_speed",
      "sms",
      "ProviderId",
    ],
    include: [
      {
        model: Service,
        attributes: ["service"],
        through: {
          attributes: [],
        },
      },
      {
        model: Provider,
        required: true,
        attributes: ["name", "contact"],
      },
      {
        model: PromoCode,
        attributes: ["promo_code"],

        // through: { where: {promo_code: null } }
      },
    ],
    where: {
      ...where,
    },
  })
    .then((response) => {
      res.status(200).send(response);
    })
    .catch((err) => {
      response.status(404).send(err);
    });
};
