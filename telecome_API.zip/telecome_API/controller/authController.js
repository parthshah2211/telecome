const User = require("../models/user");
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs');
const { realpath } = require("fs");
const stripe = require("stripe")("sk_test_51LUsbOSFn9zBQXri3fTLXCmbYUQl2aBcZWcRTVqaA53LyCKSom5JmUHPxvoQflNZsiqJbbnwMCjETvtO4z4rIrnK00iXNwFxqF");


exports.postSignUp = async (req, res, next) => {
  // const userDetail = {
  //   email: req.body.user_email,
  //   password: req.body.user_password,
  //   userName: req.body.user_name
  // }
  let customerId
  res.setHeader('Set-Cookie', 'visited=true; Max-Age=3000; HttpOnly, Secure')
  // console.log(res, "checkk");
  // sessions defined in app js
  const name = req.body.name
  const email = req.body.email
  const password = req.body.password
  console.log(name, email, password)
  // User.findOne({ email }).then((userDoc) => {
  //   if (userDoc) {
  //     return res.send('user match')
  //   }
  const customer = await stripe.customers.create({
    email: email,
    name:name
  }).then(res => {
    console.log(res)
    customerId=res.id 
  });
    return bcrypt.hash(password, 12).then((hashPassword) => {
        User.create({
          name: name,
          email: email,
          password: hashPassword,
          customerId:customerId
      }) 
      res.send("done")
    })
  }
  exports.postLogin = (req, res, next) => {
    const email = req.body.email
    const password = req.body.hashPassword
    console.log(email, password)
    let userLoaded
    User.findOne({ where: {email:email}  }).then((user) => {
      if (!user) {
        const error = new Error('User not found')
        error.statusCOde = 401
        error.message = 'User not found'
        return res.send(error)
      }
      userLoaded = user
      const hashPass = user.password
      const customerId=user.customerId
      console.log(user)
      bcrypt
        .compare(password, hashPass)
        // return true false value
        .then((doMatch) => {
          if (doMatch) {
            // pass the user id into jwt token
            const id = userLoaded.id
            // set JWT token fist argument attch email in second arhument argument jwt token secrate,in third argument attach expire time
            const token = jwt.sign({ email, customerId }, 'jasaka', { expiresIn: '1h' })
            // session
            res.setHeader('Set-Cookie', 'loggedIn=true', 'HttpOnly')
            // req.session.isLoggedIn = true
            // req.session.user = user
            // console.log(req.session)
            // console.log(req.session.user)
            // this return stop the excution of next line because it's retrurn promise
            // almost evey return statmnet stop the excution of upcoming line
            if (token) {
              return res.status(200).json({ token, message: 'user login successful' })
            }
            // return req.session.save((err) => {
            //   console.log(err)
            //   res.status(200).json({ token, message: 'user login successful' })
            // })
          }
          res.send('password or email incorrect')
        })
    })
  }