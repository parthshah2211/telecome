const { request } = require("express");
const Payment = require("../models/payment");

const stripe = require("stripe")("sk_test_KkylUw7T4dtWp4TsnurTfeCr00oVHZX6jj");

exports.payment =async (request, response) => {
  console.log(request.body, "cardDetail")
  const price = request.body.price
  console.log( request.userId,"userId")
 
  try {
    let intent;
    if (request.body.payment_method_id) {
      // Create the PaymentIntent
        intent = await stripe.paymentIntents.create({
        payment_method: request.body.payment_method_id,
          amount: request.body.price * 100,
          customer: request.userId,
          setup_future_usage: 'off_session',
          // automatic_payment_methods: {
          //   enabled: true,
          // },
        currency: 'inr',
        confirmation_method: 'manual',
        confirm: true
      })
    } else if (request.body.payment_intent_id) {   
      intent = await stripe.paymentIntents.confirm(
      request.body.payment_intent_id
      );
    }
    // Send the response to the client
    Payment.create({
      brand: request.body.cardDetail.brand,
      last4Dig: request.body.cardDetail.last4,
      amount: request.body.price,
      tarId: "123",
      mobileNo:"9898989920"
    }).then(res => {
     
    })
    response.send(generateResponse(intent))
  } catch (e) {
    // Display error on client
    return response.send({ error: e.message });
  }
};
const generateResponse = (intent) => {
  // Note that if your API version is before 2019-02-11, 'requires_action'
  // appears as 'requires_source_action'.
  if (
    intent.status === 'requires_action' &&
    intent.next_action.type === 'use_stripe_sdk'
  ) {
    // Tell the client to handle the action
    return {
      requires_action: true,
      payment_intent_client_secret: intent.client_secret
    };
  } else if (intent.status === 'succeeded') {
    // The payment didn’t need any additional actions and completed!
    // Handle post-payment fulfillment
   
    return {
      success: true
    };
  } else {
    // Invalid status
    return {
      error: 'Invalid PaymentIntent status'
    }
  }
};

exports.paymentElement =async (req, res) => {
  console.log(req.userId, 'userId', req.body.price)
  // Create a PaymentIntent with the amount, currency, and a payment method type.
  //
  // See the documentation [0] for the full list of supported parameters.
  //
  // [0] https://stripe.com/docs/api/payment_intents/create
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      currency: 'GBP',
      amount:50,
      // payment_method_types: ['card'], 
   
      // customer: request.userId,/
    
      // payment_method_types: ['card'],
        automatic_payment_methods: {enabled: true},
    });
    // Send publishable key and PaymentIntent details to client
    res.send(

      {
      clientSecret: paymentIntent.client_secret,
    });
  } catch (e) {
    console.log(e)
    return res.status(400).send({
      error: {
        message: e.message,
      },
    });
  }
}