// import the express module
const express = require('express');
const cors = require("cors");

// payment setup
const { queryParser } = require('express-query-parser')
const userRoute = require('./routes/user');
const providerRoutes=require('./routes/provider')
const serviceRoutes= require('./routes/service');
const planRoutes= require('./routes/plan');
const zipRoutes= require('./routes/zip')
const promoCodeRoutes= require('./routes/promoCode')
// const stripe = require("stripe")("sk_test_51LUsbOSFn9zBQXri3fTLXCmbYUQl2aBcZWcRTVqaA53LyCKSom5JmUHPxvoQflNZsiqJbbnwMCjETvtO4z4rIrnK00iXNwFxqF");
const uuid = require("uuid").v4;
const paymentRoute = require('./routes/paymentRoute')
const bodyParser = require('body-parser')
// express configuration
const app = express();
// const port = process.env.PORT || 3000;
//  routes intilized
// body parser config
//crosse platform

// app.use(cors());
app.use(cors())
// app.use((req, res, next) => {
//   // res.setHeader('Access-Control-Allow-Origin', '*')
//   res.append('Access-Control-Allow-Origin', ['*']);
//   res.setHeader(
//     'Access-Control-Allow-Methods',
//     'OPTIONS, GET, POST, PUT, PATCH, DELETE'
//   )
//   res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')
//   next()
// })
// const whitelist = ["http://localhost:3000","https://www.youtube.com/watch?v=2kc-FjU2-mY"]
// const corsOptions = {
//   origin: function (origin, callback) {
//     if (!origin || whitelist.indexOf(origin) !== -1) {
//       callback(null, true)
//     } else {
//       callback(new Error("Not allowed by CORS"))
//     }
//   },
//   credentials: true,
// }
// app.use(cors(corsOptions))
app.use(express.json()) // for body parser
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
  extended: true
}))
// routes configuration
// app.set('query parser', 'simple');
app.use('/admin', userRoute)
app.use(paymentRoute)
app.use('/provider', providerRoutes)
app.use('/service',serviceRoutes) 
app.use('/plan',planRoutes)
app.use('/zipcode', zipRoutes)
// app.use(paymentRoute)
app.use('/promocode',promoCodeRoutes)
// db connectionConfig import
// db relationships

// payment setup
// app.get("/", (req, res) => {
//   res.send("sk_test_51LUsbOSFn9zBQXri3fTLXCmbYUQl2aBcZWcRTVqaA53LyCKSom5JmUHPxvoQflNZsiqJbbnwMCjETvtO4z4rIrnK00iXNwFxqF");
// });
 
// app.post('/create-checkout-session', async (req, res) => {
//   const session = await stripe.checkout.sessions.create({
//     line_items: [
//       {
//         price_data: {
//           currency: 'usd',
//           product_data: {
//             name: 'T-shirt',
//           },
//           unit_amount: 2000,
//         },
//         quantity: 1,
//       },
//     ],
//     mode: 'payment',
//     success_url: 'https://stripe.com/docs/api/payment_intents',
//     cancel_url: 'https://stripe.com',
//   });

//   res.send("hello");
// });


// app.post('/pay', async (request, response) => {
//   console.log(request.body, "cardDetail")
//   const price = request.body.price
 
//   try {
//     let intent;
//     if (request.body.payment_method_id) {
//       // Create the PaymentIntent
//         intent = await stripe.paymentIntents.create({
//         payment_method: request.body.payment_method_id,
//           amount: request.body.price * 100,
//           customer: "cus_MI9X3XkWfAvw9X",
//           setup_future_usage: 'off_session',
//           // automatic_payment_methods: {
//           //   enabled: true,
//           // },
//         currency: 'inr',
//         confirmation_method: 'manual',
//         confirm: true
//       })
//     } else if (request.body.payment_intent_id) {
//       intent = await stripe.paymentIntents.confirm(
//       request.body.payment_intent_id
//       );
//     }
//     // Send the response to the client
//     Payment.create({
//       brand: request.body.cardDetail.brand,
//       last4Dig: request.body.cardDetail.last4,
//       amount: request.body.price,
//       tarId: "123",
//       mobileNo:"9898989920"
//     }).then(res => {
     
//     })
//     response.send(generateResponse(intent))
//   } catch (e) {
//     // Display error on client
//     return response.send({ error: e.message });
//   }
// });
// const generateResponse = (intent) => {
//   // Note that if your API version is before 2019-02-11, 'requires_action'
//   // appears as 'requires_source_action'.
//   if (
//     intent.status === 'requires_action' &&
//     intent.next_action.type === 'use_stripe_sdk'
//   ) {
//     // Tell the client to handle the action
//     return {
//       requires_action: true,
//       payment_intent_client_secret: intent.client_secret
//     };
//   } else if (intent.status === 'succeeded') {
//     // The payment didn’t need any additional actions and completed!
//     // Handle post-payment fulfillment
   
//     return {
//       success: true
//     };
//   } else {
//     // Invalid status
//     return {
//       error: 'Invalid PaymentIntent status'
//     }
//   }
// };
// app.post("/checkout", async (req, res) => {
//   console.log("Request:", req.body);
//   const price=req.body.product.detail.price
//   let error;
//   let status;
//   try {
//     let paymentId
//     let intentId
//     const { product, token } = req.body;
//     stripe.customers.create({
//       name: "parth",
//       email: "shahParthsp11@gmail.com",
//     }).then(customer => {
//       customerObj = customer;
//       console.log(customer,"customers")
//     })

//     stripe.paymentMethods.create({
//       type: 'card',
//       card: {
//         number: '4242424242424242',
//         exp_month: 8,
//         exp_year: 2023,
//         cvc: '314',
//       },
//     }).then(res => {
//       console.log("customerData: ",customerObj)
//       console.log(res.id)
//         paymentId =res.id
//         stripe.paymentIntents.create({
//         amount: price,
//         currency: 'usd',
//         payment_method: paymentId,
//         payment_method_types: ['card'],
//         customer: customerObj.id,
//         confirmation_method:"manual",

//       }).then(res => {
//       console.log("final payment response : ",res)
//       intentId=res.id
//       }).then(re => {
//       paymentIntent =stripe.paymentIntents.confirm(
//          intentId,
//         { payment_method: paymentId },
//         res.send(generateResponse(paymentIntent))
//         )
//     });
//     })
//     console.log("Charge:");
//     status = "success";
//   } catch (error) {
//     console.error("Error:", error);
//     status = "failure";
//   }
//   res.json({ error, status });
// });
// app.post('/secret', async (req, res) => {
//   const paymentIntent = await stripe.paymentIntents.create({
//     amount: 2099,
//     currency: 'inr',
//     // automatic_payment_methods: {
//     //       enabled: true,
//     //     },
//     shipping: {
//       name: 'parth shah',
//       address: {
//         line1: '12,Vrundavan Nagar Bamroli',
//         city: 'godhra',
//         state: 'gujrat',
//         country: 'IN',
//         postal_code: '389001',
//       },
//     }
//   });
//   // const intent = await stripe.paymentIntents.create({
//   //   amount: 1099,
//   //   currency: "inr",
//   //   automatic_payment_methods: {
//   //     enabled: true,
//   //   },
//   //   // payment_method_types:['card','sepa_debit','giropay','eps'],
//   //   // automatic_payment_methods: { enabled: true },
//   //   shipping: {
//   //     name: 'Jenny Rosen',
//   //     address: {
//   //       line1: '1234 Main Street',
//   //       city: 'San Francisco',
//   //       state: 'CA',
//   //       country: 'US',
//   //       postal_code: '94111',
//   //     },
//   //   },
//   // }
//   // );
//   // console.log(res)
//   res.send({paymentIntent});
// });

// app.post('/create-payment-intent', async (req, res) => {
//   const {paymentMethodType, currency} = req.body;
// console.log(paymentMethodType, currency)
//   // Each payment method type has support for different currencies. In order to
//   // support many payment method types and several currencies, this server
//   // endpoint accepts both the payment method type and the currency as
//   // parameters.
//   //
//   // Some example payment method types include `card`, `ideal`, and `alipay`.
//   const params = {
//     payment_method_types: [paymentMethodType],
//     amount: 5999,
//     currency: currency,
//   }

//   // If this is for an ACSS payment, we add payment_method_options to create
//   // the Mandate.
//   if(paymentMethodType === 'acss_debit') {
//     params.payment_method_options = {
//       acss_debit: {
//         mandate_options: {
//           payment_schedule: 'sporadic',
//           transaction_type: 'personal',
//         },
//       },
//     }
//   } else if (paymentMethodType === 'konbini') {
//     /**
//      * Default value of the payment_method_options
//      */
//     params.payment_method_options = {
//       konbini: {
//         product_description: 'Tシャツ',
//         expires_after_days: 3,
//       },
//     }
//   } else if (paymentMethodType === 'customer_balance') {
//     params.payment_method_data = {
//       type: 'customer_balance',
//     }
//     params.confirm = true
//     params.customer = req.body.customerId || await stripe.customers.create().then(data => data.id)
//   }

//   /**
//    * If API given this data, we can overwride it
//    */
//   // if (paymentMethodOptions) {
//   //   params.payment_method_options = paymentMethodOptions
//   // }

//   // Create a PaymentIntent with the amount, currency, and a payment method type.
//   //
//   // See the documentation [0] for the full list of supported parameters.
//   //
//   // [0] https://stripe.com/docs/api/payment_intents/create
//   try {
//     const paymentIntent = await stripe.paymentIntents.create({
//       payment_method_types: ['card'],
//       amount: 500 * 100,
//       customer: "cus_MI9X3XkWfAvw9X",
//     currency: 'inr',
//     }
// );

//     // Send publishable key and PaymentIntent details to client
//     res.send({
//       clientSecret: paymentIntent.client_secret,
//       nextAction: paymentIntent.next_action,
//     });
//   } catch (e) {
//     return res.status(400).send({
//       error: {
//         message: e.message,
//       },
//     });
//   }
// });
// app.get('/create-payment-intent', async (req, res) => {
//   console.log("hi")
//   // Create a PaymentIntent with the amount, currency, and a payment method type.
//   //
//   // See the documentation [0] for the full list of supported parameters.
//   //
//   // [0] https://stripe.com/docs/api/payment_intents/create
//   try {
//     const paymentIntent = await stripe.paymentIntents.create({
//       currency: 'inr',
//       amount: 1999,
//       payment_method_types: ['card'],  
//         // payment_method_types: ['card', 'ach_credit_transfer', 'paper_check'],
//       // automatic_payment_methods: true 
//     });

//     // Send publishable key and PaymentIntent details to client
//     res.send({
//       clientSecret: paymentIntent.client_secret,
//     });
//   } catch (e) {
//     return res.status(400).send({
//       error: {
//         message: e.message,
//       },
//     });
//   }
// });
const sequelize = require('./utils/database');
const Zipcode = require('./models/zipcode');
const Provider = require('./models/provider');
const Service = require('./models/service');
const Plan = require('./models/plans');
const { provider } = require('./controller/providerController');
const PromoCode = require('./models/promocode');
const Payment = require('./models/payment');
const { request } = require('express');

// DEFINE RELATIONSHIPS BETWEEN TABLES
Service.belongsToMany(Provider, { through: 'servicehasproviders' });
Provider.belongsToMany(Service, { through: 'serviceproviders' });
Plan.belongsToMany(Service, { through: 'planHasServices' });
Service.belongsToMany(Plan, { through: 'planHasServices' });
// Service.hasMany(Plan, {
//   foreignKey: 'Plan_Id'
// });
// Plan.belongsTo(Service);
// Provider.hasMany(Plan, {
//   foreignKey: 'Provider_Id'
// });
Plan.belongsTo(Provider,{
  foreignKey: {
    allowNull: false
  }
});

// PromoCode.hasOne(Plan, {
//   foreignKey: 'PromoCode_Id'
// })
Plan.belongsTo(PromoCode);
// Payment.belongsTo(Plan);
sequelize
.sync()
  // .sync()
  .then(result => {
    app.listen(3030);
  })
  .catch(err => {
    console.log(err);
  });
