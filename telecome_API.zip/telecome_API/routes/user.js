const express = require('express')
const router = express.Router()
// import controller

const authController= require('../controller/authController')

// post login routes

// router.post('/login',authController.postLogin)

router.post('/login',authController.postLogin)
router.post('/postSignUp',authController.postSignUp)
module.exports = router