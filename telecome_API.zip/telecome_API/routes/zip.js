const express = require('express')
const router = express.Router()
// import controller

const zipController= require('../controller/zipCodeController')

// post create plan routes
router.post('/create', zipController.zipCodeCreateController)

// get display plan routes

router.get('/display',zipController.showZipCodeController)


module.exports = router