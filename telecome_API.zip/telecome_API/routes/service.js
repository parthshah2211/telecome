const express = require('express')
const router = express.Router()
// import controller

const serviceController= require('../controller/serviceController')

// post login routes

router.post('/create',serviceController.service)

module.exports = router