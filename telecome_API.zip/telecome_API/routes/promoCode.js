const express = require('express')
const router = express.Router()
// import controller

const promoCodeController= require('../controller/promoCodeController')

// post login routes

router.post('/create',promoCodeController.promoCode)

module.exports = router