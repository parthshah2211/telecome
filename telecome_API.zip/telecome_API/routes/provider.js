const express = require('express')
const router = express.Router()
// import controller

const providerController= require('../controller/providerController')

// post login routes
console.log("parth")
router.post('/create',providerController.provider)
router.get('/display', providerController.providerDisplay)
router.get('/plan',providerController.providerPlanDisplay)
module.exports = router