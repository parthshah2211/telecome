const express = require('express')
const router = express.Router()
// import controller

const planController= require('../controller/planController')
const isAuth = require('../middleware/isAuth')

// post create plan routes
router.post('/create',planController.createPlan)

// get display plan routes

router.get('/display',
    // isAuth,
    planController.showPlanController)



module.exports = router