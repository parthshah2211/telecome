const express = require('express')
const router = express.Router()
const paymentApi = require("../controller/paymentController");
const isAuth = require('../middleware/isAuth');
// payment route
// router.post('/create-payment-intent',
//     isAuth,
//     paymentApi.payment)

router.post('/create-payment-intent',
// isAuth,
    paymentApi.paymentElement)
module.exports = router