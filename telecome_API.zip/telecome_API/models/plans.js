const  Sequelize=require('sequelize');

const sequelize=require('../utils/database')

const Plan=sequelize.define('Plan',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
name:{
    type:Sequelize.STRING,
},
price:{
    type:Sequelize.DOUBLE,
    allowNull: false
},
des:{
    type:Sequelize.STRING,
    allowNull:false
},
talk_time:{
    type:Sequelize.STRING,
},
data:{
    type:Sequelize.STRING,
   
},
validity:{
    type:Sequelize.INTEGER,
    allowNull:false
},
type:{
    type:Sequelize.STRING,
    allowNull:false
},
data_speed:{
    type:Sequelize.STRING,
    
},
sms:{
    type:Sequelize.STRING,
   },
   ProviderId:{
        type: Sequelize.INTEGER,
        allowNull: false,
       
   },
})
module.exports=Plan