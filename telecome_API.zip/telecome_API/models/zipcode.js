const  Sequelize=require('sequelize');
const sequelize=require('../utils/database')

const Zipcode=sequelize.define('zipcodes',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
zip_code:{
    type:Sequelize.INTEGER,
    allowNull: false
}
})
module.exports=Zipcode