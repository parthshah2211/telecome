const  Sequelize=require('sequelize');
const sequelize=require('../utils/database')

const Service=sequelize.define('Service',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
service:{
    type:Sequelize.STRING,
},
})
module.exports= Service