const  Sequelize=require('sequelize');
const sequelize=require('../utils/database')

const PromoCode=sequelize.define('PromoCode',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
promo_code:{
    type:Sequelize.STRING,
    allowNull: false
    },
    promo_code_detail: {
        type:Sequelize.STRING,
        allowNull: false
}

})
module.exports=PromoCode