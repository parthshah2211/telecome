// connect using mysql connection

// const mysql=require('mysql2')
// const pool=mysql.pool({
//     host:'localhost',
//     user:'root',
//     database:'telecom',
//     password:'132456',
// });
// module.exports=pool.promise();

// connect using sequelize

// constructor function
// import configuration file
const Config=require('../config/config.json')
const  Sequelize=require('sequelize');
const sequelize= new Sequelize(Config.development.database,Config.development.username,Config.development.password,{
    dialect:'mysql',
    host:'localhost'
}) 
module.exports=sequelize