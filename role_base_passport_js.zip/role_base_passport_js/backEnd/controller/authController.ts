import express, { Request, Response } from "express";
import { NextFunction } from "express";
import postSignUpController from "../services/userServices"

const postSignUp = async (req: Request, res: Response, next: NextFunction) => {
    postSignUpController.postSignUp(req,res,next)
  }
 const postLogin = (req :Request, res : Response, next : NextFunction) => {
    postSignUpController.postLogin(req,res,next)
  }
  export default {
    postSignUp,
    postLogin,
  }