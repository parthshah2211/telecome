// connect using mysql connection

// const mysql=require('mysql2')
// const pool=mysql.pool({
//     host:'localhost',
//     user:'root',
//     database:'telecom',
//     password:'132456',
// });
// module.exports=pool.promise();

// connect using sequelize

// constructor function
// import configuration file

//@ts-ignore
import Config from '../utils/config.json' ;
import Sequelize from 'sequelize';
//@ts-ignore
const sequelize = new Sequelize(Config.development.database,Config.development.username,Config.development.password,{
    dialect:'mysql',
    host:'localhost',
    port: Config.development.port
})
export default sequelize