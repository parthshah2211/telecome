import Sequelize from 'sequelize';
//@ts-ignore
import db from '../database/database';
import { Iuser } from '../interFace/interFace';

interface Irole{
  [x: string]: any;
  id: number,
  name:string,
}
const Roles :Irole  = db.define('roles', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true
  }
});

export default Roles