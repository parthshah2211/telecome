import Sequelize from 'sequelize';
//@ts-ignore
import db from '../database/database';
import { Iuser } from '../interFace/interFace';

const User :Iuser  = db.define('user', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true
  },
  email: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true
  },
  password: {
    type: Sequelize.STRING,
    allowNull: false
    }
});

export default User