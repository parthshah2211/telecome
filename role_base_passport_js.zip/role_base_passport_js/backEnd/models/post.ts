import Sequelize from 'sequelize';
//@ts-ignore
import db from '../database/database';
import { Iuser } from '../interFace/interFace';

const Post :Iuser  = db.define('post', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true
  },
  detail: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true
  },
  image: {
    type: Sequelize.STRING,
    allowNull: false
    }
});

export default Post