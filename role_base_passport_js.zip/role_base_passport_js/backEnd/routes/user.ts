import express from 'express'
const router = express.Router()
// import controller

import authController from '../controller/authController'
import passport from 'passport';

// post login routes

router.post('/login',authController.postLogin)
router.post('/postSignUp', authController.postSignUp)
router.get('/protected',passport.authenticate('jwt', { session: false }), function (req, res) {
    res.json('Success! You can now see this without a token.')
  })
export default router