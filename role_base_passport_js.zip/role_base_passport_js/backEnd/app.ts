import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import sequelize from "./database/database";
import session from "express-session";
import passport from 'passport';
import passportLocal from 'passport-local';
import cookieParser from 'cookie-parser';
import userRoute from './routes/user'
import User from "./models/user";
import Roles from "./models/userHasRole";
import Post from "./models/post";
import strategy from "./middleware/passportJWT";
import passportJWT from 'passport-jwt';
import { Ipasport } from "./interFace/interFace";
//express set up
//@ts-ignore
// let ExtractJwt = passportJWT.ExtractJwt;
// let JwtStrategy = passportJWT.Strategy;

// let jwtOptions: Ipasport = {
//     // @ts-ignore
//     jwtFromRequest :ExtractJwt.fromAuthHeaderAsBearerToken(),
//     secretOrKey :'wowwow'
// };
// //@ts-ignore
// passport.use(new JwtStrategy(jwtOptions, function(jwt_payload, next) {
//   console.log('payload received', jwt_payload);
// //   let user = getUser({ id: jwt_payload.id });
// //   if (user) {
// //     next(null, user);
// //   } else {
// //     next(null, false);
// //   }
// }));
const app = express();
app.use(passport.initialize());
app.use(cors());
app.use(express.json()); // for body parser
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
// app.use(session({
//     secret: "secretcode",
//     resave: true,
//     saveUninitialized: true,
// }))
app.use(cookieParser());
// app.use(passport.initialize());
// app.use(passport.session());

// route
app.use('/admin', userRoute)

User.belongsToMany(Roles, { through: 'userHasRole'});
Roles.belongsToMany(User, { through: 'userHasRole'});
User.hasMany(Post)
Post.belongsTo(User)
sequelize.sync()
  .then((result: object) => {
    app.listen(3030);
  })
  .catch((err: object) => {
    //   throw new  Error(err)
    console.log(err);
  });
