import passport from 'passport';
import passportJWT from 'passport-jwt';
import { Ipasport } from '../interFace/interFace';
import User from '../models/user';

let ExtractJwt = passportJWT.ExtractJwt;
let JwtStrategy = passportJWT.Strategy;

let jwtOptions: Ipasport = {
    // @ts-ignore
    jwtFromRequest :ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey :'wowwow'
};


// lets create our strategy for web token
// @ts-ignore
let strategy = new JwtStrategy(jwtOptions, function(jwt_payload: { email: string; }, next: (arg0: null, arg1: boolean) => void) {
    console.log('payload received', jwt_payload);
     User.findOne({
        where: { email: jwt_payload.email } 
        //@ts-ignore
     }).then((user) => {
        console.log(user,"user====")
        if (user) {
            next(null, user);
          } else {
            next(null, false);
          }    
     }).catch((err :object ) => {
         console.log(err)
     })


});
passport.use(strategy)
export default {
    strategy,
    jwtOptions
}

function done(err: any, arg1: boolean) {
    throw new Error('Function not implemented.');
}
