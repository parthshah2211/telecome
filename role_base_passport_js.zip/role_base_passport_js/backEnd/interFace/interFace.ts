import passportJWT from 'passport-jwt';
export interface Iuser{
    [x: string]: any;
    id: number;
    name: string;
    email: string;
    password: string;
    customerId: string;
}
export interface Ires{
    id:number;
}
export interface IuserRegister{
  password: string,
  customerId:number,
  id:number
}
export interface IError {
  error ? :Error
  statusCOde ? : number;
  message? : string;
}
export interface Ipasport{
  jwtFromRequest: typeof passportJWT.ExtractJwt,
  secretOrKey:string
}


