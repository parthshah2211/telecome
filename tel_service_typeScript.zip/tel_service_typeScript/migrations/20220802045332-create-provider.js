'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Providers', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
    Name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
     Price: {
        type: Sequelize.DOUBLE,
        allowNull: false,
      },
     Logo: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      Des: {
        allowNull: false,
        type: Sequelize.STRING
      },
   Contact: {
        allowNull: false,
        type: Sequelize.INTEGER
      },
      Website: {
        allowNull: false,
        type: Sequelize.STRING
      },
      zipCode: {
        allowNull: false,
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Providers');
  }
};