'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Plans', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      Name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      Price: {
        type: Sequelize.DOUBLE,
        allowNull: false
      },
      PlanValidity: {
        type: Sequelize.STRING,
        allowNull: false
      },
      Des: {
        type: Sequelize.STRING,
        allowNull: false
      },
     Type: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      DataSpeed: {
        type: Sequelize.STRING,
        allowNull: false
      },
      SMS: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      ProviderId: {
        type: Sequelize.STRING,
        allowNull: false
      },
      ServiceId: {
        type: Sequelize.STRING,
        allowNull: false
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Plans');
  }
};