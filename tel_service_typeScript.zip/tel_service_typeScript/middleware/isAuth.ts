import express, { Request, Response ,NextFunction} from "express";
import jwt, { Secret, JwtPayload } from 'jsonwebtoken';
interface Ierror{
  error:Error,
  statusCode:number,
  
}
// interface Request{
//   userId:number
// }
interface CustomRequest extends Request {
 decodedToken: string | JwtPayload;
}
const isAuth = (req :Request, res:Response, next:NextFunction) => {
  const authHeader = req.get('Authorization')
  if (!authHeader) {
    // @ts-ignore
    const error:Ierror = new Error('Not authenticated.')
    error.statusCode = 401
    throw error
  }
  const token = authHeader.split(' ')[1]
  
  try {
  let   decodedToken = jwt.verify(token, 'jasaka')
  //@ts-ignore
    req.userId=decodedToken.userId
  } catch (err) {
    // @ts-ignore
    err.statusCode = 500
    throw err
  }
  // if (!decodedToken) { 
  //   // @ts-ignore
  //   const error :Ierror = new Error('Not authenticated.')
  //   error.statusCode = 401
  //   throw error
  // }

  next()
}
export default isAuth
