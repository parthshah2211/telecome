// import the express module
import express from 'express';
import cors from "cors";
import userRoute from './routes/user';
import providerRoutes from './routes/provider'
import serviceRoutes from './routes/service';
import planRoutes from './routes/plan';
import zipRoutes from './routes/zip';
import promoCodeRoutes from './routes/promoCode';
const uuid = require("uuid").v4;
// import paymentRoute from './routes/paymentRoute';
import bodyParser from 'body-parser';
// express configuration
const app = express();
app.use(cors())
app.use(express.json()) // for body parser
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
  extended: true
}))
app.use('/admin', userRoute)
// app.use(paymentRoute)
app.use('/provider', providerRoutes)
app.use('/service',serviceRoutes) 
app.use('/plan',planRoutes)
app.use('/zipcode', zipRoutes)
app.use('/promocode',promoCodeRoutes)
import sequelize from './utils/database';
import Zipcode from './models/zipcode';
import Provider from './models/provider';
import Service from './models/service';
import Plan from './models/plans';
// import { provider } from './controller/providerController';
import PromoCode from './models/promocode';
// import Payment from './models/payment';
// import { request } from 'express';

// DEFINE RELATIONSHIPS BETWEEN TABLES
Service.belongsToMany(Provider, { through: 'servicehasproviders' });
Provider.belongsToMany(Service, { through: 'serviceproviders' });
Plan.belongsToMany(Service, { through: 'planHasServices' });
Service.belongsToMany(Plan, { through: 'planHasServices' });
Plan.belongsTo(Provider,{
  foreignKey: {
    allowNull: false
  }
});
Plan.belongsTo(PromoCode);
app.listen(3030);

