import Sequelize from 'sequelize';
//@ts-ignore
import db from '../utils/database';

interface Iuser{
    id: number;
    name: string;
    email: string;
    password: string;
    customerId: string;
}
const User :Iuser  = db.define('user', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
      type: Sequelize.STRING,
      allowNull: false
  },
  email: {
      type: Sequelize.STRING,
      allowNull: false
  },
  password: {
    type: Sequelize.STRING,
    allowNull: false
    }, 
    customerId: {
        type: Sequelize.STRING,
        allowNull: false
  }
});

module.exports = User;