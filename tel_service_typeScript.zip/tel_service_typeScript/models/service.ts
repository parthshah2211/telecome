import Sequelize from 'sequelize';
import sequelize from '../utils/database';

const Service=sequelize.define('Service',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
service:{
    type:Sequelize.STRING,
},
})
export default Service