import Sequelize from 'sequelize';
import sequelize from '../utils/database';

const PlanHasService=sequelize.define('planhasservices',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
PlanId:{
    type:Sequelize.INTEGER,
    allowNull: false
},
ServiceId:{
  type:Sequelize.INTEGER,
  allowNull: false
}
})
export default PlanHasService