const  Sequelize=require('sequelize');
const sequelize=require('../utils/database')

const Payment=sequelize.define('payment',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
brand:{
    type:Sequelize.STRING,
    allowNull: false
},
last4Dig: {
        type:Sequelize.STRING,
        allowNull: false
},
amount: {
        type:Sequelize.STRING,
        allowNull: false
},   
tarId:{
  type:Sequelize.STRING,
  allowNull: false
    },
    mobileNo: {
type:Sequelize.STRING,

},
})
module.exports=Payment