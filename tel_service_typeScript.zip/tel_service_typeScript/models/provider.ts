import Sequelize from 'sequelize';
import sequelize from '../utils/database';

const Provider=sequelize.define('Provider',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
name:{
    type:Sequelize.STRING,
},
logo:{
    type:Sequelize.STRING,
    allowNull:false
},
des:{
    type:Sequelize.STRING,
    allowNull:false
},
contact:{
    type:Sequelize.STRING,
    defaultValue:0,
},
website:{
    type:Sequelize.STRING,
    defaultValue:0,
},
zip_code:{
    type:Sequelize.STRING,
    allowNull:false
}
})
export default Provider