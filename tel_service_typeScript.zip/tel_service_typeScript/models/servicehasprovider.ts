import Sequelize from 'sequelize';
import sequelize from '../utils/database';

const ServiceHasProvider=sequelize.define('ServiceHasProvider',{
id:{
    type:Sequelize.INTEGER,
    autoIncrement:true,
    allowNull:false,
    primaryKey: true,
},
ServiceId:{
    type:Sequelize.INTEGER,
    allowNull: false
},
ProviderId:{
  type:Sequelize.INTEGER,
  allowNull: false
}
})
export default ServiceHasProvider