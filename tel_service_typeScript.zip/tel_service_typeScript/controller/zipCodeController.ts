import { response } from 'express'
import zipCodeModel from '../models/zipcode'
import express, { Request, Response ,NextFunction} from "express";


const zipCodeCreateController=(req:Request,res:Response,next:NextFunction) => {
    const zipCode=req.body.zipCode
    zipCodeModel.create({
        zip_code:zipCode
    }).then((response :object)=>{
        res.status(201).send(response)
        console.log(response)
    }).catch((err:object) => {
        res.status(422).send(err)
    })
}

// showZipCode
const showZipCodeController = (req:Request,res:Response,next:NextFunction)=>{
    zipCodeModel.findAll().then((response:object) => {
        console.log(response+"response")
        res.status(200).send(response)}).catch((err:object)=>{
            response.status(404).send(err)
        })    
}
export default{
    showZipCodeController,
    zipCodeCreateController
}