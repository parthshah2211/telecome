var Sequelize = require("sequelize");
var Op = Sequelize.Op;
const Publishable_Key = 'pk_test_51LUsbOSFn9zBQXriWHmsgtatq0cnYfY1XMvLoA7APoTDwsXEmFkvHTv7jGu9T9N6XAQSk8OhB4MakAAShkY6qtDf00HdQYQunr'
import { response } from "express";
//@ts-ignore
import { globalMessages } from "../global/globalMessage";
import Plan from "../models/plans";
import PromoCode from "../models/promocode";
import Provider from "../models/provider";
import express, { Request, Response ,NextFunction} from "express";
import Service from "../models/service";
import PlanHasService from "../models/planHasService";
import { where } from "sequelize";


interface IcreatePlan{
  id:number
}
// create plan controllers
interface Iwhere{ validity:string |object | null, data_speed:string |object | null, data:string |object | null,  ProviderId:string |object | null,ProviderName:string |object | null } 
const createPlan = (req:Request, res: Response, next:NextFunction) => {
  const name = req.body.name;
  const price = req.body.price;
  const des = req.body.des;
  const TalkTime = req.body.TalkTime;
  const data = req.body.data;
  const validity = req.body.validity;
  const type = req.body.type;
  const dataSpeed = req.body.dataSpeed;
  const sms = req.body.sms;
  const providerId = req.body.providerId;
  const serviceId = req.body.serviceId;
  Plan.create({
    name: name,
    price: price,
    des: des,
    talk_time: TalkTime,
    data: data,
    type: type,
    validity: validity,
    data_speed: dataSpeed,
    sms: sms,
    PromoCodeId: req.body.promoCodeId,
    // ServiceId:req.body.serviceId,
    ProviderId: providerId,
  })
    .then((response:IcreatePlan) => {
      let id = response.id;
      for (let i = 0; i < serviceId.length; i += 2) {
        let service = serviceId[i];
        PlanHasService.create({
          PlanId: id,
          ServiceId: service,
        });
      }
      return res.status(201).send(globalMessages.PLANCREATEDSUCCSSFULL);
    })
    .catch((err :Object) => {
      console.log(err + "error");
      res.status(422).send(globalMessages.PLANCREATEDFAIL);
    });
};

// show plan controller
const showPlanController = (req:Request, res:Response, next:NextFunction) => {
  const operatorsAliases = {
    $like: Op.like,
  };
  const { validity, data_speed, data, promo_code, ProviderId,ProviderName }= req.query;
    var where:Iwhere | null |any
    ={
      data:data ? data:null,  
      validity:validity? validity:null,
      data_speed:data_speed? data_speed:null,
      ProviderId:ProviderId? ProviderId:null,
    }
    const whereProviderName=ProviderName ? { name:ProviderName} : {} 
    if (validity!=null)
    {
      where.validity= validity.toString().split(",").length == 1 ? {  [Op.like]: `%${validity}%` } : { [Op.in]: validity.toString().split(",") };
    }
  if (data_speed!=null) {
      if (data_speed.toString().split(',').length == 1) {
        where.data_speed = { [Op.like]: `%${data_speed}%` };
    }
      else {
      where.data_speed = { [Op.in]: data_speed.toString().split(',') };
    }
  }
  if (data!=null) {
      if (data.toString().split(',').length == 1)
      {
          
      where.data = { [Op.like]: `%${data}%` };
    }
    else {
        
      where.data = { [Op.in]: data.toString().split(',') };
    }
  }
  if (ProviderId!=null) {
      if (ProviderId.toString().split(',').length == 1)
      {
         
      where.ProviderId = { [Op.like]: `%${ProviderId}%` };
      }
      else {
      
      where.ProviderId = { [Op.in]: ProviderId.toString().split(',') };
    }
  }
  Object.keys(where).forEach((key,value) => {
    console.log(key,"key",value)
  if (where[key] == null) {
    delete where[key];
  }
});
  console.log(ProviderName,"where",where);
  Plan.findAndCountAll(
    {
    attributes: [
      "name",
      "price",
      "des",
      "talk_time",
      "data",
      "validity",
      "type",
      "data_speed",
      "sms",
      "ProviderId",
    ],
    include: [
      // {
      //   model: Service,
      //   //  required: true,
      //   attributes: ["service"],
      //   // through: {
      //   // // attributes: [],
      //   // },
      // },
      {
        model: Provider,
        required: true,
        attributes: ["name", "contact"],
        where: whereProviderName
      },
      {
        model: PromoCode,
        attributes: ["promo_code"],
        // through: { where: {promo_code: null } }
      },
    ],
    // offset: 0,
    // limit: 3,
    where: {
          //@ts-ignore
      ...where,
    }  
  }
  )
    .then((response:Object) => {
      res.status(200).send(response);
    })
    .catch((err:object) => {
      response.status(404).send(err);
    });
};
export default{
  createPlan,
  showPlanController
}
