//@ts-ignore
import User from "../models/user";
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import express, { Request, Response } from "express";
import { realpath } from "fs";
import { NextFunction } from "express";
// const stripe = require("stripe")("sk_test_51LUsbOSFn9zBQXri3fTLXCmbYUQl2aBcZWcRTVqaA53LyCKSom5JmUHPxvoQflNZsiqJbbnwMCjETvtO4z4rIrnK00iXNwFxqF");
interface Ires{
    id:number;
}
interface Iuser{
  password: string,
  customerId:number,
  id:number
}
interface IError {
  error ? :Error
  statusCOde ? : number;
  message? : string;
}
const postSignUp = async (req :Request, res :Response,  next : NextFunction) => {
  // const userDetail = {
  //   email: req.body.user_email,
  //   password: req.body.user_password,
  //   userName: req.body.user_name
  // }
  let customerId : number 
  res.setHeader('Set-Cookie', 'visited=true; Max-Age=3000; HttpOnly, Secure')
  // console.log(res, "checkk");
  // sessions defined in app js
  const name = req.body.name
  const email = req.body.email
  const password = req.body.password
  console.log(name, email, password)
  User.findOne({ email }).then((userDoc:object) => {
    if (userDoc) {
      return res.send('user already exists')
    }
    else{
   return bcrypt.hash(password, 12).then((hashPassword) => {
        User.create({
          name: name,
          email: email,
          password: hashPassword,
          customerId:customerId
      }) 
      res.send("user created successfully")
    })
    }
}).catch((err:object)=>{
  console.log(err)
})
 
  }
 const postLogin = (req :Request, res : Response, next : NextFunction) => {
    const email = req.body.email
    const password = req.body.hashPassword
    console.log(email, password)
    let userLoaded :Iuser
    User.findOne({ where: {email:email}  }).then((user :Iuser) => {
      if (!user) {
        const error : IError ={}
        error.statusCOde = 401
        error.message = 'User not found'
        return res.send(error)
      }
      userLoaded = user
      const hashPass = user.password
      const customerId=user.customerId
      console.log(user)
      bcrypt
        .compare(password, hashPass)
        // return true false value
        .then((doMatch) => {
          if (doMatch) {
            // pass the user id into jwt token
            const id = userLoaded.id
            // set JWT token fist argument attch email in second arhument argument jwt token secrate,in third argument attach expire time
            const token = jwt.sign({ email, customerId }, 'jasaka', { expiresIn: '1h' })
            // session
          // @ts-ignore
            res.setHeader('Set-Cookie', 'loggedIn=true', 'HttpOnly')
            // req.session.isLoggedIn = true
            // req.session.user = user
            // console.log(req.session)
            // console.log(req.session.user)
            // this return stop the excution of next line because it's retrurn promise
            // almost evey return statmnet stop the excution of upcoming line
            if (token) {
              return res.status(200).json({ token, message: 'user login successful' })
            }
            // return req.session.save((err) => {
            //   console.log(err)
            //   res.status(200).json({ token, message: 'user login successful' })
            // })
          }
          res.send('password or email incorrect')
        })
    })
  }
  export default {
    postSignUp,
    postLogin,
  }