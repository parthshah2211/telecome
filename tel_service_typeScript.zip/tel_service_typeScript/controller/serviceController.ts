
const Service= require("../models/service")
import express, { Request, Response,NextFunction } from "express";

const service=(req:Request,res:Response,next:NextFunction)=>{
const service=req.body.service
console.log(service)
Service.create({
    service:service,
}).then((response:object) => {
res.send(response)
}).catch((err:object)=>{
    console.log(err)
    res.status(500).send("Server Error");
})

}
export default service