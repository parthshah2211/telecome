var Sequelize = require('sequelize');
var Op = Sequelize.Op;
import express, { Request, Response,NextFunction } from "express";
import  globalMessages  from "../global/globalMessage";
import Plan from '../models/plans';
import Provider from "../models/provider";
import ServiceHasProvider from "../models/servicehasprovider";
import zipCode1 from "../models/zipcode";


interface Iprovider{
    id:number;
    name:string;
}
const provider =(req:Request,res:Response,next :NextFunction)=>{
const name=req.body.name
const logo=req.body.logo
const des=req.body.des
const contact=req.body.contact
const website=req.body.website
const serviceId=req.body.serviceId
const zipCode=req.body.zipCode
    Provider.create({
        name:name,
        logo:logo,
        des:des,
        contact:contact,
        website:website,
        zip_code:zipCode,  
    })
.then((response :Iprovider) => {
    // console.log(response.id,"hello world")
    const providerId=response.id
    console.log(providerId)
   for(let i=0; i<serviceId.length; i+=2){
    let service=serviceId[i]
    console.log(service,"helllo")
    ServiceHasProvider.create({
        ServiceId:service,
        ProviderId:providerId,
    }).then(() => {
    })
   }
}).then(()=>{
    res.status(201).send(globalMessages.PROVIDERADDEDSUCCESSFULLY)
})
.catch(()=>{
    res.send(globalMessages.PROVIDERADDEDFAIL)

})
}
const providerDisplay=(req :Request,res :Response,next : NextFunction)=>{
    Provider.findAll(  
        // attributes["id","name","des","contact","website",""],
    )
    .then((response : object)=>{
       res.status(200).send(response)
    }).catch(()=>{
    })
}
const providerPlanDisplay = (req :Request, res :Response, next :NextFunction) => {
    Provider.findAll(
        {
            include:
                [
                    {
                        model:Plan,
                        attributes: ["plan"],
                        through: {
                            attributes: []
                          }
                    },
            ]
        }  
    )
    .then((response:Object)=>{
       console.log(response)
       res.status(200).send(response)
    }).catch(()=>{
 res.status(401).send("somthing gose wrong")
    })
}
export default{
    provider,
    providerDisplay,
    providerPlanDisplay
}