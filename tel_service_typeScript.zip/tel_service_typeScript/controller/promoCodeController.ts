
import promoCode from "../models/promocode"
import express, { Request, Response ,NextFunction} from "express";

const promoCodeController =(req:Request,res:Response,next:NextFunction)=>{
    const promo_code = req.body.promo_code
    const promo_code_detail = req.body.promo_code_detail
    console.log(promo_code,promo_code_detail)
promoCode.create({
    promo_code: promo_code,   
    promo_code_detail:promo_code_detail
}).then((response:object) => {
res.send(response)
}).catch((err:object)=>{
    console.log(err)
    res.status(500).send("Server Error");
})
}
export default promoCodeController