// eslint-disable-next-line quotes

const globalMessages = {
    PLANCREATEDSUCCSSFULL: 'plan added successfully',
    LOGINSUCCSSFULL: 'login successfully',
    PLANCREATEDFAIL: 'plan added failed',
    LOGINFAIL: 'login  failed',
    PROVIDERADDEDSUCCESSFULLY: 'Provider added successfully',
    PROVIDERADDEDFAIL: `Provider can't added`,
    LOGONOTFOUND: 'logo not found',
    NOTAUTHORIZED: 'not authorized',
    NOTFOUND: 'not found',
    VALIDATION:
    {
      name: 'minimum 3 letters required',
      password: '',
      email: 'email address is invalid',
      emailTaken: 'email is already in use',
      dataValidation: 'entered data is invalid'
    }
  }
  export default globalMessages
  