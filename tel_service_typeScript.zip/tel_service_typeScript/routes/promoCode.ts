import promoCodeController from '../controller/promoCodeController'
import express from 'express'
const router = express.Router()

router.post('/create',promoCodeController)

export default router