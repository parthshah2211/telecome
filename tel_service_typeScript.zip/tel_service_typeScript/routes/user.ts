import express from 'express'
const router = express.Router()
// import controller

import authController from '../controller/authController'

// post login routes

router.post('/login',authController.postLogin)
router.post('/postSignUp',authController.postSignUp)
export default router