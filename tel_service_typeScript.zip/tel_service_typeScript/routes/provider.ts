import express from 'express'
const router = express.Router()
// import controller

import providerController from '../controller/providerController'

// post login routes
console.log("parth")
router.post('/create',providerController.provider)
router.get('/display', providerController.providerDisplay)
router.get('/plan',providerController.providerPlanDisplay)
export default router