import express from 'express'
const router = express.Router()
// import controller

import zipController from '../controller/zipCodeController'

// post create plan routes
router.post('/create', zipController.zipCodeCreateController)

// get display plan routes

router.get('/display',zipController.showZipCodeController)


export default router