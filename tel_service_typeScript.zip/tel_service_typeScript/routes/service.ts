import express from 'express'
const router = express.Router()
import serviceController from '../controller/serviceController'
router.post('/create',serviceController)
export default router