// app.post('/create-checkout-session', async (req, res) => {
//   const session = await stripe.checkout.sessions.create({
//     line_items: [
//       {
//         price_data: {
//           currency: 'usd',
//           product_data: {
//             name: 'T-shirt',
//           },
//           unit_amount: 2000,
//         },
//         quantity: 1,
//       },
//     ],
//     mode: 'payment',
//     success_url: 'https://stripe.com/docs/api/payment_intents',
//     cancel_url: 'https://stripe.com',
//   });

//   res.send("hello");
// });
let customerObj;

// app.post("/checkout", async (req, res) => {