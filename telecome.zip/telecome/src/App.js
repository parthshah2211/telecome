
import { useContext, useEffect, useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import './App.css';
import Card from './components/card/card';
import Provider from './components/card/provider';
import Header from './components/layOut/header/header';
import planServices from './services/planService';
import ProviderServices from './services/providerService';
import { useSelector, useDispatch } from 'react-redux'
import { planSlice } from './redux/slices/planSlice';
import Form from './components/form/form';
import Login from '../src/components/login/login.jsx' 
import PrivateRoute from './routes/routes';
import AuthContext from './store/auth-context';
import  axios  from 'axios';
import { Url } from './global/globalConstant';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import CheckoutForm from './checkOutForm';
import PaymentStatus from './paymentStatus';
import GooglePay from './checkOutForm';
import Completion from './completation';
import Payment from './paymentStatus';
function App() {
  const [providerDetail, setProvider] = useState([]);
  const [secret, setSecret] = useState(null);
const[options,setOptions] = useState()
  // destructuring props
  // get the provider details

  const getProvider = () => {
    ProviderServices.showProvider()
      .then(result => {
        // dispatch(item
        // )
        setProvider(result)
      }
        //   console.log(result.Plans[0].imageUrl)
      )
      .catch(error => console.log('error', error))
  }

  useEffect(() => {
    console.log("hi")

    getProvider()
  }, [])
  const stripePromise = loadStripe('pk_test_ctYKYVcCTatYNgECgpzyMQTx00mkjWy0pB');
  
//   const paymentElement = async () => {
//     const res = await axios.get(Url+'secret', {
//       headers : { 
//         'Content-Type': 'application/json',
//         'Accept': 'application/json'
//        }
//     }).then(res => {
//       console.log(res.data)
//       setSecret(res.data.client_secret)
//       setOptions(
//         {
//           // passing the client secret obtained in step 2
//           clientSecret:secret,
//           // Fully customizable with appearance API.
//           appearance: {/*...*/},
//         }
// ) 
//     })
     
//   }
return (
    <>
      {/* {animals.map((animal) => (
        <h1>{animal.type}</h1>
      ))}
      <button onClick={() => handleClick()}>Update the State</button> */}
      <Header />  
    <Routes>
    <Route path="/" element={<Payment stripePromise={stripePromise} />} />
        <Route path="/completion" element={<Completion stripePromise={stripePromise} />} />
        <Route path="/provider" element={<Provider item={providerDetail} ></Provider>} /> 
        <Route   path="/status"  element={ <PaymentStatus ></PaymentStatus>} /> 
        <Route path="/plan/:id" element={<Card></Card>}  /> 
    </Routes> 
      <PrivateRoute></PrivateRoute> 
    {/* <button onClick={()=>paymentElement()}>pay me</button> */}
      {/* <Elements stripe={stripePromise}>
      <CheckoutForm />
    </Elements> */}
      {/* {secret ? (
        <Elements stripe={stripePromise} options={{
          clientSecret:secret
        }}>        
      <CheckoutForm />
    </Elements>
      ) : (
          <></>
      )} */}
    {/* <Elements stripe={stripePromise} >
       <CheckoutForm />
    </Elements>  */}
    {/* <GooglePay></GooglePay> */}
      {/* <Routes>
      <Route   path="/provider"  element={ <Provider item={providerDetail} ></Provider>} /> 
      </Routes>
      <PrivateRoute></PrivateRoute> */}
   </>
  );
}

export default App;
