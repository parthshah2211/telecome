import React, { useState } from 'react'

const AuthContext = React.createContext({
  toke: '',
  isLoggedIn: false,
  login: (token) => {

  },
  logout: () => {}
})

export const AuthContextProvider = (props) => {
  console.log("hello auth")
  const [token, setToken] = useState(null)

  // truthy false value shorcut
  const useIsloggedIn = !!token

  const loginHandler = (token) => {
    console.log(token)
    setToken(token)
  }
  const logoutHandler = (token) => {
    setToken(null)
  }

  const contextValue = {
    token,
    isLoggedIn: useIsloggedIn,
    login: loginHandler,
    logout: logoutHandler
  }
  return <AuthContext.Provider value={contextValue}>{props.children}</AuthContext.Provider>
}
export default AuthContext
