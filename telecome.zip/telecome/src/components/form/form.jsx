import { useState } from "react"
import authService from "../../services/authService"
import './form.css'
const Form = () => {
    const [user_email, setUser_email] = useState()
    const [user_name, setUser_name] = useState()
    const [user_password, setUser_password] = useState()
    const handleRegister = (e) => {
      e.preventDefault()
      authService.register(user_email, user_name, user_password)
    }
    return (
          <>
              <body>
        <div className="row">
      <div className="col-md-12">
        <form onSubmit={handleRegister} id="userData">
          <h1> Sign Up </h1>
          <fieldset>
            <legend><span className="number">1</span> Your Basic Info</legend>
            <label htmlFor="name">Name:</label>
            <input type="text" id="name" name="user_name" onChange={e => setUser_name(e.target.value)}/>
            <label htmlFor="email">Email:</label>
            <input type="email" id="mail" name="user_email" onChange={e => setUser_email(e.target.value)}/>
            <label htmlFor="password">Password:</label>
            <input type="password" id="password" name="user_password" onChange={e => setUser_password(e.target.value)} />
          </fieldset>
          <button type="submit" className="signUp" >Sign Up</button>
         </form>
          </div>
        </div>
        
      </body>
          </>
    )
}
export default Form;