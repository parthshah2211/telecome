import React from "react";
import './title.css'
const Title=({title,className})=>{
    return(
        <>
<div class="one">
          <h1 style={{ fontSize:className }}>{title}</h1>
</div>


  

        </>
    )
}
export default Title