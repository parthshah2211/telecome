import React from "react";

const ContentLayout= (props) => {
    return(
        <>
          <div className={props.className}>
            {props.children}   
        </div>
    
        </>
    )
}
export default ContentLayout;