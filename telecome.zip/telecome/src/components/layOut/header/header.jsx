import React from "react";
import { Link } from 'react-router-dom'
import  ('./header.css')
const Header=()=>{
    return(
<>
<nav className="navbar navbar-expand-lg navbar-light bg-light">
  <div className="container-fluid">
   <Link className="nav-link active" to="">MobileWala</Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarScroll">
      <ul className="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll-position-absolute top-0 end-0"  >
        <li className="nav-item">
        <Link className="nav-link active" to="provider">Provider</Link>
        </li>
        <li className="nav-item dropdown">
          <Link  className="nav-link dropdown-toggle" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" to="services">Services</Link>
          <ul className="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
            <li>
            <Link className="nav-link active" to="internet">Internet</Link>
                </li>
            <li>
            <Link className="nav-link active" to="calling">Calling</Link>
                 </li>
            <li><hr className="dropdown-divider" /></li>
            <li>
            <Link className="nav-link active" to="sms">Sms</Link>
                </li>
          </ul>
        </li>

      </ul>
      <form className="d-flex">
        <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
        <button className="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

</>
    )
}
export default Header