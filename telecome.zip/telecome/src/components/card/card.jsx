import React, { useContext, useEffect, useState } from "react";
import planServices from "../../services/planService";
import Title from "../layOut/title/title";
import {  useParams } from "react-router-dom";
import AuthContext from "../../store/auth-context";
import Payment from './../../paymentStatus';
import { loadStripe } from "@stripe/stripe-js";
import GooglePay from "./googelPay";


const Card = () => {
  
  const stripePromise = loadStripe('pk_test_ctYKYVcCTatYNgECgpzyMQTx00mkjWy0pB');
  // const options = {
  //   // passing the client secret obtained from the server
  //   clientSecret: '{{CLIENT_SECRET}}',
  // };
  const [item, setItem] = useState([]);
  const [data, setData] = useState([]);
  const [speed, setSpeed] = useState();
  const [dataPack, setDataPack] = useState(null);
  const [check, setChecked] = useState(null);
  const [validity, setValidty] = useState(null);
  const [spinner, setSpinner] = useState(false);
  const [price, setPrice] = useState(null);
  const [name, setName] = useState(null);
  const [valid, setValid] = useState(null);
  const[provider,setProvider]=useState(null);
  let { id } = useParams();
  const authCtx = useContext(AuthContext)
  const token = authCtx.token

  console.log(authCtx)
  const getThePlan = (data, dataPack, speed, validity) => {
    setSpinner(true);
    planServices
      .showPlan(id, data, dataPack, speed, validity)
      .then((result) => {
        setItem(result.data);
        setDataPack([]);
        setData([]);
        setSpinner(false);
        setSpeed([]);
        setValidty([]);
      })
      .catch((error) => {
        alert("something Wrong");
        setSpinner(false);
      });
  };
  const handelFilter = (e) => {
    setSpinner(true);
    e.preventDefault();
    // console.log(myArray);
    console.log(data)    
    if (check == true) 
    {
      console.log(data, dataPack, speed, validity);
      getThePlan(data, dataPack, speed, validity);
    }
    else {
      getThePlan();
    }
  };
  useEffect(() => {
    console.log("hi");
    getThePlan();
  }, []);
  const style = {
    fontSize: "25PX",
  };
  const handelRecharge = (price, name, validity,provider) => {
    console.log(price, name, validity);
    setPrice(price);
    setName(name);
    setValid(validity);
    setProvider(provider);
  };
  return (
    <>
      {spinner ? (
        <>
          <div class="d-flex justify-content-center">
            <div class="spinner-border" role="status">
              <span class="visually-hidden">Loading...</span>
            </div>
          </div>
        </>
      ) : (
        <></>
      )}
      <Title title={"PLAN"}></Title>
      <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPBcSQfeqxs82cyMYa9GdghUHSc8X6lu7gYA&usqp=CAU" class="d-block w-100" alt="..." />
      <div class="carousel-caption d-none d-md-block">
        <h5>Airtel</h5>
              <p>
              India's largest telecom service provider for customer & business. Buy postpaid, broadband plans in India. Online recharge prepaid & postpaid
        </p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="2000">
      <img src="https://assets.airtel.in/static-assets/new-home/img/banners/desktop/banner-2.jpg?v=1660659261853&hash=81" class="d-block w-100" alt="..." />
      <div class="carousel-caption d-none d-md-block">
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="https://assets.airtel.in/static-assets/new-home/img/banners/desktop/banner-4.jpg?v=1660659261853&hash=81" class="d-block w-100" alt="..." />
      <div class="carousel-caption d-none d-md-block">
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
      
      <div className="filter">
        <button
          class="btn btn-default"
          type="button"
          data-toggle="collapse"
          data-target="#mobile-filter"
          aria-expanded="false"
          aria-controls="mobile-filter"
        >
          Filters<span className="fa fa-filter pl-1"></span>
        </button>
      </div>
      <div id="mobile-filter">
        <div>
          <h6 class="p-1 border-bottom">Home Furniture</h6>
          <ul>
            <li>
              <a href="#">Living</a>
            </li>
            <li>
              <a href="#">Dining</a>
            </li>
            <li>
              <a href="#">Office</a>
            </li>
            <li>
              <a href="#">Bedroom</a>
            </li>
            <li>
              <a href="#">Kitchen</a>
            </li>
          </ul>
        </div>
        <div>
          <h6 className="p-1 border-bottom">Filter By</h6>
          <p className="mb-2">Color</p>
          <ul className="list-group">
            <li className="list-group-item list-group-item-action mb-2 rounded">
              <a href="#">
                {" "}
                <span className="fa fa-circle pr-1" id="red"></span>Red{" "}
              </a>
            </li>
            <li className="list-group-item list-group-item-action mb-2 rounded">
              <a href="#">
                {" "}
                <span className="fa fa-circle pr-1" id="teal"></span>Teal{" "}
              </a>
            </li>
            <li className="list-group-item list-group-item-action mb-2 rounded">
              <a href="#">
                {" "}
                <span className="fa fa-circle pr-1" id="blue"></span>Blue{" "}
              </a>
            </li>
          </ul>
        </div>
        <div>
          <h6>Type</h6>
          <form className="ml-md-2">
            <div className="form-inline border rounded p-sm-2 my-2">
              {" "}
              <input type="radio" name="type" id="boring" />{" "}
              <label for="boring" className="text-center">
                Boring
              </label>{" "}
            </div>
            <div className="form-inline border rounded p-sm-2 my-2">
              {" "}
              <input type="radio" name="type" id="ugly" />{" "}
              <label for="ugly" className="text-center">
                Ugly
              </label>{" "}
            </div>
            <div className="form-inline border rounded p-md-2 p-sm-1">
              {" "}
              <input type="radio" name="type" id="notugly" />{" "}
              <label for="notugly" className="text-center">
                Not Ugly
              </label>{" "}
            </div>
          </form>
        </div>
      </div>
      <section id="sidebar">
        <div>
          <form className="ml-md-2" onSubmit={handelFilter} id="userData">
            <h6 className="mt-3 mb-3">Per Day Data</h6>
            <input
              id="cb1" 
                className="form-check-input mt-0"
                type="checkbox" 
                value="6GB"
                onChange={(e) => {
                 setData([e.target.value,...data])     
                  setChecked(e.target.checked);
                }}

            />
  <label for="cb1" className="text-center">
  6GB
            </label>
               <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb2"     
              value="5GB"
              onChange={(e) => {
                setData([e.target.value,...data])
                  setChecked(e.target.checked);
                }}
              />
              <label  for="cb2" className="text-center">5GB</label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb3"
                value="3GB"
              onChange={(e) => {
                setData([e.target.value,...data])
                setChecked(e.target.checked);
                }}
              />
              <label  for="cb3" className="text-center">3GB</label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb4"
                value="2.5GB"
              onChange={(e) => {
                setData([e.target.value,...data])
                setChecked(e.target.checked);
                }}
              />
              <label  for="cb4" className="text-center">2.5GB</label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb5"
                value="1GB"
                onChange={(e) => {
                  setData([e.target.value,...data])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb5" className="text-center">1GB</label>{" "}
            <h6 className="mt-3 mb-3">Internet Speed</h6>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb6"
                value="135MBPS"
                onChange={(e) => {
                  setSpeed([e.target.value,...speed])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb6" className="text-center">
                135MBPS
              </label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                value="130MBPS"
                onChange={(e) => {
                  setSpeed(e.target.value);
                  setChecked(e.target.checked);
                }}
                id="cb7"
              />
              <label for="cb7" className="text-center">
                130MBPS
              </label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb8"
                value="115MBPS"
                onChange={(e) => {
                  setSpeed([e.target.value,...speed])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb8" className="text-center">
                115MBSP
              </label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb9"
                value="110MBPS"
                onChange={(e) => {
                  setSpeed([e.target.value,...speed])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb9" className="text-center">
                110MBSP
              </label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb10"
                value="80MBPS"
              onChange={(e) => {
                setSpeed([e.target.value,...speed])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb10" className="text-center">
                80MBSP
              </label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb11"
                value="45MBPS"
                onChange={(e) => {
                  setSpeed([e.target.value,...speed])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb11" className="text-center">
                45MBPS
              </label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb12"
                value="35MBPS"
                onChange={(e) => {
                  setSpeed([e.target.value,...speed])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb12" className="text-center">
                35MBSP
              </label>
            
            <h6 className="mt-3 mb-3">Plan validity</h6>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb13"
                value="365"
              onChange={(e) => {
                           setValidty([e.target.value,...validity])
                           setChecked(e.target.checked);
                }}
              />
              <label for="cb13" className="text-center">365 Days</label>{" "}
         
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb14"
                value="85"
                onChange={(e) => {
                  setValidty([e.target.value,...validity])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb14" className="text-center">85 Days</label>
            
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb15"
                value="84"
                onChange={(e) => {
                  setValidty([e.target.value,...validity])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb15" className="text-center">84 Days</label>
          
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb16"
                value="56"
                onChange={(e) => {
                  setValidty([e.target.value,...validity])
                  setChecked(e.target.checked);
                }}
              />
              <label  for="cb16" className="text-center">56 Days</label>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb17"
                value="28"
                style={{ width:"100%", height:"30px"}}
                onChange={(e) => {
                  setValidty([e.target.value,...validity])
                  setChecked(e.target.checked);
                }}
                placeholder="28 Days"
              />
              <label cb="cb17" className="text-center">28 Days</label>
            <h6 className="mt-3 mb-3">Plan type</h6>
              <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb18"
                value="unlimited Plan"
                onChange={(e) => {     setDataPack([e.target.value,...dataPack])
                  setChecked(e.target.checked);
                }}
              />
              <label  for="cb18" className="text-center">unlimited Plan</label>
            <input
                className="form-check-input mt-0"
                type="checkbox"
                id="cb19"
                value="Data Pack"
                onChange={(e) => {
                  setDataPack([e.target.value,...dataPack])
                  setChecked(e.target.checked);
                }}
              />
              <label for="cb19" className="text-center">Data Pack</label>
        
            <div className="card-body pt-3">
              <button type="submit" class="btn btn-danger">
                Apply Filter
              </button>
            </div>
          </form>
        </div>
      </section>
      <section id="products">
        <div className="container">
          <div className="row">
            {item.map((Val) => {
              console.log(Val.Provider.name)
              return (
                <>
                  <div className="col-lg-4 col-sm-4 col-4">
                    <div className="card mt-4">
                      {/* <img
                        src="https://s3-ap-southeast-1.amazonaws.com/bsy/iportal/images/airtel-logo-red-text-horizontal.jpg"
                        class="rounded-circle"
                        alt="Cinque Terre"
                        width="84"
                        height="76"
                        style={{
                          position: "absolute",
                          top: "-36px",
                          left: "-22px",
                          objectFit: "initial",
                        }}
                      /> */}

                      <Title
                        title={Val.name}
                        className={style.fontSize}
                      ></Title>
                      <img
                        className="card-img-top"
                        src="https://pwa-cdn.freecharge.in/pwa-static/pwa/images/dcc/mobile.svg"
                        alt="Card image cap"
                      />
                      <div className="card-body">
                        <span class="badge mx-3 rounded-pil  bg-danger">
                          Price{Val.price}₹
                        </span>
                        <span class="badge mx-3 rounded-pil bg-danger">
                          Per Day Data:{Val.data}
                        </span>
                        <span class="badge mx-3 rounded-pil bg-danger">
                          validity {Val.validity}
                        </span>
                        <span class="badge mx-3 rounded-pil bg-danger">
                          Internet Speed:{Val.data_speed}
                        </span>
                        <p className="card-text" style={{ paddingTop: "10px" }}>
                          {Val.des}
                        </p>
                        <div class="d-grid gap-2">
                          <button
                            class="btn btn-primary btn-danger"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            data-bs-whatever="@mdo"
                            onClick={() => {
                              handelRecharge(Val.price, Val.name, Val.validity,Val.Provider.name);
                            }}
                            type="button"
                          >
                            Recharge Now
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              );
            })}
          </div>
        </div>
      </section>
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              {<Title title={"Recharge Now"}></Title>}
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body ">
            <h4 class="ms-3 danger text-danger"> Plan Details</h4>
              <div class="card ms-3" style={{ width: "18rem" }}>
                <ul class="list-group list-group-flush">
                <li class="list-group-item">Provider name:{provider}</li>
                  <li class="list-group-item">name:{name}</li>
                  <li class="list-group-item">Price:{price}₹</li>
                  <li class="list-group-item">Validty:{valid} Days</li>
                </ul>
              </div> 
                <div class="mb-3">
                  <label for="recipient-name" class="col-form-label" style={{border:"0px"}}>
                    Enter Mobile Number
                  </label>
                  <input type="text" class="form-control" id="recipient-name" />
                </div>
                <div class="mb-3">
              </div>
              {/* <GooglePay></GooglePay> */}
              <Payment stripePromise={stripePromise}  price={price} />
            </div>
            </div>
          </div>
        </div>
    </>
  );
};

export default Card;
