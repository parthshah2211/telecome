import React from "react";


const cardLayout = (props) => {
    return (
        <>
              <div className={props.class1}>
                <div className={props.class2}>
                    {props.children}
                </div>  
                </div>
        </>
    )
}
export default cardLayout;