// import React, { useContext, useState } from 'react';
// import {useStripe, useElements, CardElement,PaymentElement} from '@stripe/react-stripe-js';
// import CardSection from './cardSection';
// import { Url } from '../../global/globalConstant';
// import axios from 'axios';
// import './payment.css'
// import AuthContext from '../../store/auth-context';
// let price;
// export default function CheckoutForm(detail) {
//   price = detail.detail.price
//   const stripe = useStripe();
//   const authCtx = useContext(AuthContext)
//   const token = authCtx.token
//   console.log(token)
//   const elements = useElements();
//   const [succeeded, setSucceeded] = useState(false);
//   const [error, setError] = useState(null);
//   const [processing, setProcessing] = useState('');
//   const [disabled, setDisabled] = useState(true);
//   const handleSubmit = async (event) => {
//     // We don't want to let default form submission happen here,
//     // which would refresh the page.
//     // get client secrate
//     event.preventDefault();
//     setProcessing(true);
  
//     if (!stripe || !elements) {
//       // Stripe.js has not yet loaded.
//       // Make sure to disable form submission until Stripe.js has loaded.
//       return;
//     }
//     const result = await stripe.createPaymentMethod({
//       type: 'card',
      
//       button:elements.PaymentRequestButtonElement,
//       card: elements.getElement(CardElement),
//       billing_details: {
//        // Include any additional collected billing details.
//         name: 'Jenny Rosen',
//         email:"test@gmail.com"
//       },
//     });
//     stripePaymentMethodHandler(result);
//   };
//   const stripePaymentMethodHandler = async (result) => {
//     if (result.error) {
//       // Show error in payment form
//     } else {
//       // Otherwise send paymentMethod.id to your server (see Step 4)
//       const res = await axios.post(Url + 'pay', {
//         payment_method_id: result.paymentMethod.id,
//         price: price,
//         cardDetail: result.paymentMethod.card
//       }, {
//         headers: {
//           Authorization: 'Bearer ' + token
//         },
//       }
    
//       )
//       const paymentResponse = res;
//       // console.log(paymentResponse)
//       // Handle server response (see Step 4)
//       handleServerResponse(paymentResponse);
//     }
//   }
//   const handleServerResponse = async (response) => {
//     if (response.error) {
//       // Show error from server on payment form
//     } else if (response.data.requires_action) {
//       // Use Stripe.js to handle the required card action
//       console.log(response.data.payment_intent_client_secret,"secrate")
//       const { paymentIntent, error } =
//         await stripe.handleCardAction(response.data.payment_intent_client_secret);
//       if (error) {
//         // Show error from Stripe.js in payment form
//       }
//       else {
//         // The card action has been handled
//         // The PaymentIntent can be confirmed again on the server
//         const serverResponse =
//         await axios.post(Url + 'pay', {
//          payment_intent_id: paymentIntent.id
//         },
//         {
//           headers: {
//             Authorization: 'Bearer ' + token
//           },
//         }
//           )
//         handleServerResponse(serverResponse);
//         console.log(serverResponse)
//         setProcessing(false);
//       }
//     } else {
//       // Show success message
//     }
//   }
//   const appearance = {
//       theme: 'stripe'
//   };
  
//   // Pass the appearance object to the Elements instance
//   const cardStyle = {
//     style: {
//       base: {
//         color: "#32325d",
//         fontFamily: 'Arial, sans-serif',
//         fontSmoothing: "antialiased",
//         fontSize: "16px",
//         "::placeholder": {
//           color: "#32325d"
//         }
//       },
//       invalid: {
//         fontFamily: 'Arial, sans-serif',
//         color: "#fa755a",
//         iconColor: "#fa755a"
//       }
//     }
//   };
//   const handleChange = async (event) => {
//     // Listen for changes in the CardElement
//     // and display any errors as the customer types their card details
//     setDisabled(event.empty);
//     setError(event.error ? event.error.message : "");
//   };
//   return (
//   //   <form className="form_Payment" onClick={handleSubmit}>
//   //     <CardSection>
//   //     <PaymentElement />
//   //     </CardSection>
    
//   //   <button>Submit</button>
//   // </form>
//   <form id="payment-form" className="form_Payment" onSubmit={handleSubmit}>
//   <CardElement id="card-element" options={cardStyle} onChange={handleChange} />
//   <button
//     disabled={processing || disabled || succeeded}
//     id="submit"
//   >
//     <span id="button-text">
//       {processing ? (
//         <div className="spinner" id="spinner"></div>
//       ) : (
//         "Pay now"
//       )}
//     </span>
//   </button>
//       </form>
//   );
// }
import {
  PaymentElement
} from '@stripe/react-stripe-js'
import {useState} from 'react'
import {useStripe, useElements} from '@stripe/react-stripe-js';

export default function CheckoutForm() {
  const stripe = useStripe();
  const elements = useElements();
  const [message, setMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!stripe || !elements) {
      // Stripe.js has not yet loaded.
      // Make sure to disable form submission until Stripe.js has loaded.
      return;
    }

    setIsLoading(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        // Make sure to change this to your payment completion page
        return_url: `${window.location.origin}/completion`,
      },
    });

    // This point will only be reached if there is an immediate error when
    // confirming the payment. Otherwise, your customer will be redirected to
    // your `return_url`. For some payment methods like iDEAL, your customer will
    // be redirected to an intermediate site first to authorize the payment, then
    // redirected to the `return_url`.
    if (error.type === "card_error" || error.type === "validation_error") {
      setMessage(error.message);
    } else {
      setMessage("An unexpected error occured.");
    }

    setIsLoading(false);
  }

  return (
    <form id="payment-form" onSubmit={handleSubmit}>
      <PaymentElement id="payment-element" />
      <button disabled={isLoading || !stripe || !elements} id="submit">
        <span id="button-text">
          {isLoading ? <div className="spinner" id="spinner"></div> : "Pay now"}
        </span>
      </button>
      {/* Show any error or success messages */}
      {message && <div id="payment-message">{message}</div>}
    </form>
  )
}