import React from "react";


const imageCard = (props) => {
    return (
        <>

        </>
    )
}
export default imageCard;