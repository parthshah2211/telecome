import { useNavigate } from "react-router-dom";
import React, { useContext, useEffect, useState } from "react";
import planServices from "../../services/planService";
import Buttons from "../layOut/button/button";
import ContentLayout from "../layOut/content/contentLayout";
import Title from "../layOut/title/title";
import { useSelector } from 'react-redux';
import { selectPlan } from "../../redux/slices/planSlice";
import "./card.css"
import AuthContext from "../../store/auth-context";
 
const Provider = ({item}) => {      
//   
const authCtx = useContext(AuthContext)
console.log(authCtx)

  let navigate = useNavigate();
  const routeChange = (id) => {

    let path = `/plan/${id}`;
    navigate(path);
    // planServices.showPlan(id).then((plan) => {
   
    // })
};  
 const props = {
   class1: "col",
   class2:"card"
  }
  // const count = useSelector(selectPlan)
  // console.log(count,"redux store")
  return (
    <>
    <Title title={"Provider"}></Title>
      {/* <Buttons menuItems={{menuItems}}></Buttons> */}
       

      <div class="row row-cols-1 row-cols-md-3 g-4">
 
        {item
            .map(Val => {
            return (
           <cardLayout  className="card" props={props}>
                <img src="https://assets.airtel.in/static-assets/new-home/img/banners/desktop/banner-1.jpg?v=1653038873041&hash=78" className="card-img-top" alt="..." />
                <div className="card-body">
                  <h5 className="card-title">{Val.name}</h5>
                  <p className="card-text">{Val.des}</p>
                </div>
                <div className="card-body">          
                  <button type="button"  onClick={()=>routeChange(Val.id)}class="btn btn-danger">    
                Get The Plan Detail
                  </button>
                </div>
                </cardLayout>
            );
          })}
  </div>
    </>
  );
};
 
export default Provider;