import { useState,useContext } from "react"
import authService from "../../services/authService"
import AuthContext, { AuthContextProvider } from "../../store/auth-context"
import './login.css'

const Login = () => {
    const [user_email, setUser_email] = useState()
    const [user_name, setUser_name] = useState()
  const [user_password, setUser_password] = useState()

  const authCtx = useContext(AuthContext)
  console.log(authCtx)
    const handleLogin = (e) => {
      e.preventDefault()
       authService.login(user_email,user_password).then(
        token => {
           console.log(token)
           console.log(authCtx)
           authCtx.login(token)
        }
      )
    }
    return (
          <>
              <body>
        <div className="row">
      <div className="col-md-12">
        <form onSubmit={handleLogin} id="userData">
          <h1> Login </h1>
          <fieldset>
            <legend><span className="number">1</span> Your Login Info</legend>
             <label htmlFor="email">Email:</label>
            <input type="email" id="mail" name="user_email" onChange={e => setUser_email(e.target.value)}/>
            <label htmlFor="password">Password:</label>
            <input type="password" id="password" name="user_password" onChange={e => setUser_password(e.target.value)} />
          </fieldset>
          <button type="submit" className="signUp" >login</button>
         </form>
          </div>
        </div>
        
      </body>
          </>
    )
}
export default Login;