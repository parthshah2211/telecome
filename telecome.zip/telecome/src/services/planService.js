import axios from 'axios';
import QueryString from 'qs';
import { Url } from '../global/globalConstant';


const showPlan = (id,data,dataPack,speed,validity) => {

  // const count = useSelector(selectCount)
    // const requestOptions = {
    //     method: 'GET',
    //     redirect: 'follow'
    //   };    
console.log(String(data).split(","))
  return axios.get(Url + "plan/display", {
    params: {
      ProviderId: id,
      data: data,
      type: dataPack,
      data_speed: speed,
      validity: validity
    },
    paramsSerializer: params => {
      return QueryString.stringify(params)
    }
  })
}
const planServices={
    showPlan
}
export default planServices