/* eslint-disable camelcase */
import { useState, useContext } from 'react'
import { Url } from '../global/globalConstant';
import axios from "axios";

const register = (email, name, password) => {
  fetch('http://127.0.0.1:3030/admin/postSignUp', {
    method: 'POST',
    body: JSON.stringify({
      email,
      name,
      password
    }),
    headers: {
      'Content-Type': 'application/json'
    }
  }).then(res => res.json())
    .then(resData => console.log(resData))
    .catch(err => {
      console.log(err)
    })
}
const login = (email, hashPassword) => {
    console.log(email, hashPassword)
   return axios.post(
      Url + "admin/login",
  {
            email: email,
            hashPassword: hashPassword
        }
    )
 
//     return fetch('http://127.0.0.1:3030/admin/login', {
//     method: 'POST',
//     body: JSON.stringify({
//       email,
//       hashPassword
//     }),
//     headers: {
//       'Content-Type': 'application/json'
//     }
//   })
      .then(resData => {
      console.log(resData.data.token);
          sessionStorage.setItem('token', resData.data.token)
          const token = resData.data.token
          return token 
     })
}
const authService = {
  register,
  login,

}
export default authService
