import { Url } from "../global/globalConstant";

const showProvider=()=>{
    console.log("hi")
      const requestOptions = {
          method: 'GET',
          redirect: 'follow'
        };    
    return fetch(Url+"provider/display", requestOptions)
    .then(response => response.json())
  }
  
  const ProviderServices={
      showProvider
  }
  export default ProviderServices