import { configureStore } from '@reduxjs/toolkit'
import planReduser from './slices/planSlice'
export const store = configureStore({
  reducer: {
    plan:planReduser
  },
})