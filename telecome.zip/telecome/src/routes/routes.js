import React, { useContext, useEffect, useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import Card from '../components/card/card'
import Form from '../components/form/form'
import Login from '../components/login/login'
import ProviderServices from '../services/providerService'
import AuthContext from '../store/auth-context'
import Provider from './../components/card/provider';

const PrivateRoute = () => {
  const authCtx = useContext(AuthContext)
  const isLoggedIn = authCtx.isLoggedIn
  console.log(isLoggedIn)
  const token = sessionStorage.getItem('token')
  const [providerDetail, setProvider] = useState([]);
    const getProvider = () => {
      
    ProviderServices.showProvider()
      .then(result => {
        // dispatch(item
        // )
        setProvider(result)
      }
        //   console.log(result.Plans[0].imageUrl)
      )
      .catch(error => console.log('error', error))
  }

  useEffect(() => {
    console.log("hi")
    getProvider()
  }, [])
console.log(isLoggedIn)
  return (
    <>{
          isLoggedIn
              ? <Routes>
   <Route path="/plan/:id" element={<Card></Card>}  />
   </Routes>
         : <Routes>
            <Route  path="/register" element={ <Form/> } />
                  <Route   path="/login"  element={<Login />} />
            {/* <Route path="/logout" element={ </> } /> */}
            </Routes>   
    }</>
  )
}
export default PrivateRoute
