import {useContext, useEffect, useState} from 'react';

import {Elements} from '@stripe/react-stripe-js';
import CheckoutForm from './components/card/paymentButton';
import { Url } from './global/globalConstant';
import  axios  from 'axios';
import AuthContext from './store/auth-context';

function Payment(props) {
  const { stripePromise } = props;
  const { price } = props
  console.log(price)
  const authCtx = useContext(AuthContext)
  const token = authCtx.token
  console.log(token)
  const [clientSecret, setClientSecret] = useState('');
  const paymentElement = async () => {
      await axios.post(Url+'create-payment-intent', {
         price:price
      },{
        headers: {
          'Authorization': `Basic ${token}` 
        }
      }
      ).then(res => {
          console.log(res.data.clientSecret)
          setClientSecret(res.data.clientSecret)
        }).catch(err => {console.log(err)})
         
      }
  useEffect(() => {
 paymentElement()
  }, []);
 console.log(clientSecret)
  return (
    <>
      <h1>Payment</h1>
      {clientSecret ? (
        <>
        <Elements stripe={stripePromise} options={{ clientSecret:clientSecret }}>
          <CheckoutForm />
        </Elements>
        </>
      ) : (
    <></>
      )}
    </>
  );
}

export default Payment;